<?php
/**
 * The theme header
 *
 * @package bootstrap-basic
 */
?>
<!DOCTYPE html>
<html class="no-js" <?php language_attributes(); ?>>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
<!--    <link rel="icon" href="/favicon.ico" type="image/x-icon">-->
    <?php wp_head(); ?>
    <script src="https://api-maps.yandex.ru/2.1/?apikey=35fec53a-f0a2-471b-a29d-773f15917ec7&lang=ru_RU"
            type="text/javascript">
    </script>
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
</head>
<body>
<header>
    <?php
    $logo = get_field('logo', 'options');
    $address = get_field('address', 'options');
    $phone = get_field('phone', 'options');
    $phone_num = preg_replace("/[^0-9]/", '', $phone);
    $instagram = get_field('instagram', 'options');
    ?>
    <div class="container header-wrapper flex-c-sb">
        <div class="header-left flex-c">
            <a href="/" class="header-logo">
                <img src="<?php echo $logo['url']; ?>" alt="">
            </a>
        </div>
        <div class="header-right">
            <div class="header-top flex-c-fe">
                <div class="header-contacts flex-c">
                    <div class="header-address header-top-item flex-c"><?php echo $address; ?></div>
                    <a href="<?php echo $phone_num; ?>" class="header-phone header-top-item flex-c"><?= $phone; ?></a>
                    <a href="<?php echo $instagram; ?>" target="_blank" class="header-inst header-top-item flex-c"></a>
                </div>

                <div class="header-lang header-top-item flex-c">
                    <span class="active">RU</span>
                    <span>EN</span>
                </div>
            </div>
            <div class="header-burger">
                <div class="header-burger-wrap">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>

            </div>
            <div class="header-nav">
              <?php
              wp_nav_menu(array(
                'theme_location' => 'main-menu',
                'menu' => '',
                'container' => 'div',
                'container_class' => '',
                'container_id' => '',
                'menu_class' => 'menu',
                'menu_id' => '',
                'echo' => true,
                'fallback_cb' => 'wp_page_menu',
                'before' => '',
                'after' => '',
                'link_before' => '',
                'link_after' => '',
                'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                'depth' => 0,
                'walker' => '',
              ));
              ?>
            </div>
            <div class="header-nav header-nav-mobile">
              <?php
              wp_nav_menu(array(
                'theme_location' => 'main-menu',
                'menu' => '',
                'container' => 'div',
                'container_class' => '',
                'container_id' => '',
                'menu_class' => 'menu',
                'menu_id' => '',
                'echo' => true,
                'fallback_cb' => 'wp_page_menu',
                'before' => '',
                'after' => '',
                'link_before' => '',
                'link_after' => '',
                'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                'depth' => 0,
                'walker' => '',
              ));
              ?>
                <div class="header-contacts flex-c">
                    <div class="header-address header-top-item flex-c"><?php echo $address; ?></div>
                    <a href="<?php echo $phone_num; ?>" class="header-phone header-top-item flex-c"><?= $phone; ?></a>
                    <a href="<?php echo $instagram; ?>" target="_blank" class="header-inst header-top-item flex-c"></a>
                </div>
            </div>

        </div>
    </div>





</header>