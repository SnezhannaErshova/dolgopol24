<?php get_header(); ?> 
<div class="error-page">
    <div class="container">
        <h1>Страница не найдена</h1>
    </div>
</div>


<?php get_footer(); ?> 