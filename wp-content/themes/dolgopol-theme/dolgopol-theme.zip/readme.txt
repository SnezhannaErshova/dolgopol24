===Bootstrap Basic===
Author: Vee Winch
Author URI: http://rundiz.com
Description: Bootstrap v.3 basic theme. For build new theme based on Bootstrap.
Text Domain: bootstrap-basic
Domain Path: /languages/
Tags: one-column, two-columns, three-columns, left-sidebar, right-sidebar, custom-background, custom-menu, featured-images, front-page-post-form, post-formats, threaded-comments, translation-ready

Bootstrap Basic WordPress theme, Copyright (C) 2018 Rundiz.com
Bootstrap Basic WordPress theme is licensed under the MIT.

Bootstrap Basic Uses Bootstrap https://getbootstrap.com/, licensed under Apache 2.0.
Bootstrap Basic Uses Font Awesome http://fontawesome.io, licensed under MIT.
Bootstrap Basic Uses Font Awesome (font files) http://fontawesome.io, licensed under SIL OFL 1.1.
Bootstrap Basic Uses html5shiv https://github.com/afarkas/html5shiv, licensed under MIT.
Bootstrap Basic Uses Modernizr https://modernizr.com, licensed under MIT.
Bootstrap Basic Uses Respond https://github.com/scottjehl/Respond, licensed under MIT.

Bootstrap Basic is based on the _s (Underscores) starter theme by Automattic Inc., licensed under GPL.

==Description==

Bootstrap v.3 basic theme. For build new theme based on Bootstrap.

==More feature==

WordPress Menu
To display menu correctly, please create at least 1 menu and set as primary and save.

Bootstrap features
This theme can use all Bootstrap classes, elements and styles.

Responsive image
For responsive image please add img-responsive class to img element.

Responsive video
Cloak video element (video element or embeded video) with <div class="flexvideo">...your video...</div>.
